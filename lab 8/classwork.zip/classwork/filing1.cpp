#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	ofstream fout;
	fout.open("file1.txt",ios::app);			//ofstream fout("file1.txt");

	if(fout.fail())
	{
		cout<<"Cant open the file...."<<endl;
		return -1;
	}
	else
	{
		//cout<<"Hello World"<<endl;
		//fout<<"Hello World"<<endl;
		int a=5;
		float f=4.5;
		char c='a';
		fout<<a<<endl
			<<f<<endl
			<<c<<endl;
	}

	fout.close();

	return 0;
}