#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	ofstream fout("file4.txt",ios::binary);

	if(fout)
	{
		for(int i=0; i<1000; i++)
		{
			int j=1000000;
			fout.write(reinterpret_cast<char *>(&j),sizeof(j));
		}
			//fout<<1000000<<endl;
	}
	else
	{
		cout<<"File operation failed..!"<<endl;
		return -1;
	}
	return 0;
}
