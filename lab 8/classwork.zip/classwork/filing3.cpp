#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	ofstream fout("file2.txt");
	if(fout)
	{
		string str = "Hello World";
		fout<<str<<endl;
		fout.close();
	}

	ifstream fin("file2.txt");
	if(fin.is_open())
	{
		string str;
		//fin>>str;
		char cstr[256];
		fin.getline(cstr,255);
		str=cstr;
		cout<<str<<endl;
		fin.close();
	}
	else
	{
		cout<<"File opening failed...!"<<endl;
		return -1;
	}
	return 0;
}