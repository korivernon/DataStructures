#include<iostream>
#include<fstream>

using namespace std;

int main(int argc, char *args[])
{	
	/*cout<<"argc = "<<argc<<endl;

	for(int i=0; i<argc; i++)
	{
		cout<<"args["<<i<<"]="<<args[i]<<endl;
	}*/
	ifstream fin(args[1]);

	if(fin)
	{
		cout<<fin.rdbuf();
	}


	return 1;
}