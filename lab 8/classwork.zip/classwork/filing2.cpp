#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	ifstream fin("file1.txt");
	if(fin.is_open())	//if(fin)
	{
		int b;
		float f1;
		char ch;
		fin>>b;
		fin>>f1;
		fin>>ch;

		cout<<b<<" "<<f1<<" "<<ch<<endl;
		fin.close();
	}
	else
	{
		cout<<"File opening failed...."<<endl;
		return -1;
	}
	return 0;
}