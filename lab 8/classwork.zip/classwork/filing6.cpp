#include<iostream>
#include<fstream>

using namespace std;
class Student
{
	private:
		int id;
		long tel;
	public:
		void set(int id, long tel)
		{
			this->id = id;
			this->tel = tel;
		}
		void get()
		{
			cout<<"ID ="<<this->id<<endl<<"Tel = "<<this->tel<<endl;
		}
};

int main()
{
	/*Student st1;
	st1.set(100,1234567);
	st1.get();

	ofstream fout("student.bin",ios::binary);
	if(fout)
	{
		fout.write(reinterpret_cast<char*>(&st1),sizeof(st1));
	}*/
	Student st2;
	ifstream fin("student.bin",ios::binary);
	if(fin)
	{
		fin.read(reinterpret_cast<char*>(&st2),sizeof(st2));
		st2.get();
		fin.close();
	}
	return 0;
}
















